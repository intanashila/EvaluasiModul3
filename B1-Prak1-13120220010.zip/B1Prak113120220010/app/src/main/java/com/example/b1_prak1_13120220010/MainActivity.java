package com.example.b1_prak1_13120220010;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Spinner spinner;
    private Button btn;
    private EditText nim;
    private EditText nama;
    private RadioGroup studi;
    private RadioButton rbTi;
    private RadioButton rbSi;
    private CheckBox bem;
    private CheckBox ilmiah;
    private CheckBox kewirausahaan;
    private CheckBox seni;
    private CheckBox jurnalistik;
    private CheckBox olahraga;


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner = findViewById(R.id.spAngkatan);
        btn = findViewById(R.id.button);
        nim = findViewById(R.id.editText1);
        nama = findViewById(R.id.txtNama);
        studi = findViewById(R.id.radioGroup);
        rbTi = findViewById(R.id.rbTi);
        rbSi = findViewById(R.id.rbSi);
        bem = findViewById(R.id.cb1);
        ilmiah = findViewById(R.id.cb2);
        kewirausahaan = findViewById(R.id.cb3);
        seni = findViewById(R.id.cb4);
        jurnalistik = findViewById(R.id.cb5);
        olahraga = findViewById(R.id.cb6);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.spAngkatan, android.R.layout.simple_spinner_dropdown_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String selectedAngkatan = spinner.getSelectedItem().toString();
                String selectedNIM = nim.getText().toString();
                String selectedNama = nama.getText().toString();
                String selectedProgramStudi = "";
                int selectedRadioButtonId = studi.getCheckedRadioButtonId(); // Mendapatkan id RadioButton yang dipilih
                if (selectedRadioButtonId != -1) { // Periksa apakah RadioButton dipilih
                    RadioButton selectedRadioButton = findViewById(selectedRadioButtonId); // Dapatkan referensi RadioButton yang dipilih
                    selectedProgramStudi = selectedRadioButton.getText().toString(); // Ambil teks dari RadioButton yang dipilih
                }
                StringBuilder selectedKegiatan = new StringBuilder();
                if (bem.isChecked()) {
                    selectedKegiatan.append("BEM, ");
                }
                if (ilmiah.isChecked()) {
                    selectedKegiatan.append("Ilmiah, ");
                }
                if (kewirausahaan.isChecked()) {
                    selectedKegiatan.append("Kewirausahaan, ");
                }
                if (seni.isChecked()) {
                    selectedKegiatan.append("Seni, ");
                }
                if (jurnalistik.isChecked()) {
                    selectedKegiatan.append("Jurnalistik, ");
                }
                if (olahraga.isChecked()) {
                    selectedKegiatan.append("Olahraga");
                }
                Intent intent = new Intent(MainActivity.this, Activity2.class);
                intent.putExtra("nim", selectedNIM);
                intent.putExtra("nama", selectedNama);
                intent.putExtra("angkatan", selectedAngkatan);
                intent.putExtra("program_studi", selectedProgramStudi);
                intent.putExtra("kegiatan", selectedKegiatan.toString());
                startActivity(intent);
            }
        });
    }
}
