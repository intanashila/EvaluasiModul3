package com.example.b1_prak1_13120220010;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Activity2 extends AppCompatActivity {

    private TextView textViewNIM;
    private TextView textViewNama;
    private TextView textViewAngkatan;
    private TextView textViewProgramStudi;
    private TextView textViewKegiatan;
    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        textViewNIM = findViewById(R.id.editTextText);
        textViewNama = findViewById(R.id.editText2);
        textViewAngkatan = findViewById(R.id.angkatan);
        textViewProgramStudi = findViewById(R.id.studi);
        textViewKegiatan = findViewById(R.id.minat);
        btn = findViewById(R.id.button2);

        Intent intent = getIntent();
        if (intent != null) {
            String nim = intent.getStringExtra("nim");
            String nama = intent.getStringExtra("nama");
            String angkatan = intent.getStringExtra("angkatan");
            String programStudi = intent.getStringExtra("program_studi");
            String kegiatan = intent.getStringExtra("kegiatan");

            textViewNIM.setText(nim);
            textViewNama.setText(nama);
            textViewAngkatan.setText(angkatan);
            textViewProgramStudi.setText(programStudi);
            textViewKegiatan.setText(kegiatan);
        }
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Activity2.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
